<?php
return array (
  'isInstalled' => true,
);
