
<div class="message_success_step">
    <?php echo $sTemplateMessage; ?>
</div>
