
-- update module version

UPDATE `sys_modules` SET `version` = '1.4.2' WHERE `uri` = 'site_customize' AND `version` = '1.4.1';

