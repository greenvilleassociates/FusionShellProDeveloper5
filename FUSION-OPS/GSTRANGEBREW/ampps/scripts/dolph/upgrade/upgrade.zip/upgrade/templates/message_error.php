
<div class="message_error">
    <?php echo $sTemplateMessage; ?>
</div>
